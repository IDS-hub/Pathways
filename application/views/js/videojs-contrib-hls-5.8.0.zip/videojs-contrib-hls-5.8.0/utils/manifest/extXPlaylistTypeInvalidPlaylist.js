{
  "allowCache": true,
  "mediaSequence": 1,
  "segments": [
    {
      "duration": 6.64,
      "timeline": 0,
      "uri": "/test/ts-files/tvy7/8a5e2822668b5370f4eb1438b2564fb7ab12ffe1-hi720.ts"
    }
  ],
  "targetDuration": 8,
  "endList": true,
  "discontinuitySequence": 0,
  "discontinuityStarts": []
}
