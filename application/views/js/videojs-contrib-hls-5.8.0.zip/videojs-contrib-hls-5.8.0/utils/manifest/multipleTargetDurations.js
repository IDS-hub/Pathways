{
  "allowCache": true,
  "mediaSequence": 0,
  "targetDuration": 10,
  "segments": [
    {
      "uri": "001.ts",
      "timeline": 0
    },
    {
      "uri": "002.ts",
      "duration": 9,
      "timeline": 0
    },
    {
      "uri": "003.ts",
      "duration": 7,
      "timeline": 0
    },
    {
      "uri": "004.ts",
      "duration": 10,
      "timeline": 0
    }
  ],
  "discontinuitySequence": 0,
  "discontinuityStarts": []
}
